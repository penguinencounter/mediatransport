from hexdoc.patchouli.page import PageWithText


class PageWithTextAlternate(PageWithText, type="hexcasting:mediatransport/text"):
    # Literally the same as the superclass
    pass
